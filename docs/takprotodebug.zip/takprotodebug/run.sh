#!/bin/sh
java -classpath protobuf-java-3.8.0.jar:./build/libs/takprotodebug.jar com.partech.takprotoparser.Parser $*
